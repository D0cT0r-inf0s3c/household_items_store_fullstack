import React from "react";

const ProductList = () => {
    const products = [
        { id: 1, name: "Vacuum Cleaner", price: "$120" },
        { id: 2, name: "Blender", price: "$45" },
        { id: 3, name: "Dish Rack", price: "$25" },
    ];

    return (
        <div>
            <h2>Products</h2>
            <ul>
                {products.map((product) => (
                    <li key={product.id}>
                        {product.name} - {product.price}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ProductList;
