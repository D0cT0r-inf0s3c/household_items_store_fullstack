let orders = [];

const getOrders = (req, res) => {
    res.json(orders);
};

const createOrder = (req, res) => {
    const newOrder = req.body;
    orders.push(newOrder);
    res.status(201).json(newOrder);
};

module.exports = { getOrders, createOrder };
