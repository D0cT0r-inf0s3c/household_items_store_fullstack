const getProducts = (req, res) => {
    const products = [
        { id: 1, name: "Vacuum Cleaner", price: 120 },
        { id: 2, name: "Blender", price: 45 },
        { id: 3, name: "Dish Rack", price: 25 },
    ];
    res.json(products);
};

module.exports = { getProducts };
